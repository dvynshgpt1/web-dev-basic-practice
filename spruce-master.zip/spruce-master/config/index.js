module.exports = {
  instagram: require("./instagram"),
  google: require("./google")
};
